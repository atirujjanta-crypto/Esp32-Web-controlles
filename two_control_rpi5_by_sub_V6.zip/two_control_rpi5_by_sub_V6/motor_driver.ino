#include "motor_driver.h"
#include "commands.h"

#define PWM_FREQ 30000
#define PWM_RES  8
#define MAX_PWM  255

void initMotorController() {
  // Attach pins directly (NEW API)
  ledcAttach(LEFT_MOTOR_FORWARD,  PWM_FREQ, PWM_RES);
  ledcAttach(LEFT_MOTOR_BACKWARD, PWM_FREQ, PWM_RES);
  ledcAttach(RIGHT_MOTOR_FORWARD, PWM_FREQ, PWM_RES);
  ledcAttach(RIGHT_MOTOR_BACKWARD, PWM_FREQ, PWM_RES);

  pinMode(LEFT_MOTOR_ENABLE, OUTPUT);
  pinMode(RIGHT_MOTOR_ENABLE, OUTPUT);

  digitalWrite(LEFT_MOTOR_ENABLE, HIGH);
  digitalWrite(RIGHT_MOTOR_ENABLE, HIGH);
}

void setMotorSpeed(int i, int spd) {
  bool reverse = false;

  if (spd < 0) {
    spd = -spd;
    reverse = true;
  }

  spd = constrain(spd, 0, MAX_PWM);

  if (i == LEFT) {
    if (!reverse) {
      ledcWrite(LEFT_MOTOR_FORWARD, spd);
      ledcWrite(LEFT_MOTOR_BACKWARD, 0);
    } else {
      ledcWrite(LEFT_MOTOR_FORWARD, 0);
      ledcWrite(LEFT_MOTOR_BACKWARD, spd);
    }
  } else {
    if (!reverse) {
      ledcWrite(RIGHT_MOTOR_FORWARD, spd);
      ledcWrite(RIGHT_MOTOR_BACKWARD, 0);
    } else {
      ledcWrite(RIGHT_MOTOR_FORWARD, 0);
      ledcWrite(RIGHT_MOTOR_BACKWARD, spd);
    }
  }
}

void setMotorSpeeds(int leftSpeed, int rightSpeed) {
  setMotorSpeed(LEFT, leftSpeed);
  setMotorSpeed(RIGHT, rightSpeed);
}
