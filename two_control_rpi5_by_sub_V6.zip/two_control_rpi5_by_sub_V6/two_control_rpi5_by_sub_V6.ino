#define BAUDRATE 115200  // กำหนดความเร็ว Serial

#include <string.h>
#include "commands.h"
#include "motor_driver.h"
#include "encoder_driver.h"
#include "servos.h"

// ตัวแปรสำหรับรับคำสั่ง
char cmd;                 // ตัวอักษรคำสั่ง เช่น b e o r s
char chr;                 // ตัวอักษรที่อ่านจาก Serial
int arg = 0;              // ตัวบอกว่าอยู่ argument ไหน
int argIndex = 0;         // index ของ argument
char argv1[16];           // เก็บ argument ตัวที่ 1
char argv2[16];           // เก็บ argument ตัวที่ 2
long arg1;                // ค่า argument ตัวที่ 1 (ตัวเลข)
long arg2;                // ค่า argument ตัวที่ 2 (ตัวเลข)

// รีเซ็ตคำสั่ง
void resetCommand() {
  cmd = 0;
  arg = 0;
  argIndex = 0;
  memset(argv1, 0, sizeof(argv1));
  memset(argv2, 0, sizeof(argv2));
}

// ประมวลผลคำสั่ง
void runCommand() {
  arg1 = atol(argv1);
  arg2 = atol(argv2);

  switch (cmd) {

    case GET_BAUDRATE:
      Serial.println(BAUDRATE);
      break;

    case READ_ENCODERS:
      Serial.print(readEncoder(LEFT));
      Serial.print(" ");
      Serial.println(readEncoder(RIGHT));
      break;

    case RESET_ENCODERS:
      resetEncoders();
      Serial.println("OK");
      break;

    case MOTOR_RAW_PWM:
      setMotorSpeeds(arg1, arg2);
      Serial.println("OK");
      break;

//////////////////SERVO_MOTOR/////////////////
    case SERVO_MOTOR:          ///////////////////////////////////////////////////////////////////
      Servo_do(arg1);          // arg1 = องศา
      Serial.println("OK");
      break;

    default:
      Serial.println("Invalid Command");
      break;
  }
}

void setup() {
  Serial.begin(BAUDRATE);

  initMotorController();
  initEncoders();
  initServos();         ///////SERVO_MOTOR////////////////
}

void loop() {
  while (Serial.available()) {
    chr = Serial.read();

    if (chr == '\r' || chr == '\n') {     // กด Enter
      if (arg == 1) argv1[argIndex] = '\0';
      if (arg == 2) argv2[argIndex] = '\0';
      runCommand();
      resetCommand();
    }
    else if (chr == ' ') {                
      if (arg == 0) {
        arg = 1;
        argIndex = 0;
      }
      else if (arg == 1) {
        argv1[argIndex] = '\0';
        arg = 2;
        argIndex = 0;
      }
    }
    else {
      if (arg == 0) {
        cmd = chr;
      }
      else if (arg == 1 && argIndex < 15) {
        argv1[argIndex++] = chr;
      }
      else if (arg == 2 && argIndex < 15) {
        argv2[argIndex++] = chr;
      }
    }
  }
}
